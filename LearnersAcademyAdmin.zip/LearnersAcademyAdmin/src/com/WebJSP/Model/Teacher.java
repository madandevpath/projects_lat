package com.WebJSP.Model;

public class Teacher {
	
	int teacherid;
	String teachername;
	String subjectname;
	
	public Teacher() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Teacher(int teacherid, String teachername, String subjectname) {
		super();
		this.teacherid = teacherid;
		this.teachername = teachername;
		this.subjectname = subjectname;
	}

	public Teacher(String teachername, String subjectname) {
		super();
		this.teachername = teachername;
		this.subjectname = subjectname;
	}

	public int getTeacherid() {
		return teacherid;
	}

	public void setTeacherid(int teacherid) {
		this.teacherid = teacherid;
	}

	public String getTeachername() {
		return teachername;
	}

	public void setTeachername(String teachername) {
		this.teachername = teachername;
	}

	public String getSubjectname() {
		return subjectname;
	}

	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}

	
	
}
