package com.WebJSP.Web;
import com.WebJSP.dao.*;
import com.WebJSP.Model.*;

import java.util.List;
import java.io.IOException;
import java.sql.SQLException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/")

public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	private UserDAO userDAO;
	private int ids;
	
    public UserServlet() {
        super();
        userDAO = new UserDAO();
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action = request.getServletPath();
		System.out.println(action);
		System.out.println("UserServlet do method called");
		try {
			switch (action)
			{
				case "/newuser":
				userAdd(request, response);
				break;

				case "/userForm":
				userform(request, response);
				break;
				
				case "/deleteUser":
					deleteUser(request,response);
					break;
				
				case "/editUser":
					editUser(request, response);
					break;

				case "/updateUser":
					updateUser(request, response);
					break;
					
				case "/adminForm":
					adminForm(request, response);
					break;

				case "/adminNewUser":
					adminNewUser(request, response);
					break;
					
				case "/classForm":
					classForm(request, response);
					break;

				case "/NewClasses":
					NewClasses(request, response);
					break;
					
				case "/DeleteClasses":
					DeleteClasses(request, response);
					break;
					
				case "/SubjectForm":
					SubjectForm(request, response);
					break;

				case "/NewSubject":
					NewSubject(request, response);
					break;
					
				case "/DeleteSubject":
					DeleteSubject(request, response);
					break;

				case "/TeacherForm":
					TeacherForm(request, response);
					break;

				case "/NewTeacher":
					NewTeacher(request, response);
					break;
					
				case "/DeleteTeacher":
					DeleteTeacher(request, response);
					break;

				case "/StudentForm":
					StudentForm(request, response);
					break;

				case "/NewStudent":
					NewStudent(request, response);
					break;
					
				case "/DeleteStudent":
					DeleteStudent(request, response);
					break;
					
				case "/list":
					userList(request, response);
					break;
					
				default:
					userList1(request, response);
						break;
			}
				
			
		}catch (Exception ex) {
			System.out.println("Exception Caught");
			System.out.println(ex.getMessage());
		}
	
	}


	private void DeleteStudent(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		
		int id = Integer.parseInt(request.getParameter("id"));
		if(userDAO.deleteStudent(id))
			{
				List<Student> StudList = userDAO.selectAllStudents(); 
				request.setAttribute("listStud", StudList);
				
				List<Classess> subList = userDAO.selectAllClasses(); 
				//System.out.println(subList);
				request.setAttribute("listSub", subList);
				
				request.getRequestDispatcher("Student-Form.jsp").include(request, response);
			}
		else
			System.out.println("There is some error in deleting Teacher.");
		
	}


	private void NewStudent(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		// TODO Auto-generated method stub

		PrintWriter writer = response.getWriter();
		String name=request.getParameter("studentname");
		String emailadr=request.getParameter("emailadr");
		String phonenbr=request.getParameter("phonenbr");
		String classname=request.getParameter("classname");
		
		System.out.println(name + "    Subject Name");
		Student newStudent = new Student(name,emailadr,phonenbr,classname);
		Boolean subExist = userDAO.insertNewStudent(newStudent);

		if (subExist)
			writer.println("<h3 style='color:green;'>Subject Already Exist.. + </h3>");	
		else
			writer.println("<h3 style='color:green;'>Subject Added Successfully.. + </h3>");
		
		
		List<Student> StudList = userDAO.selectAllStudents(); 
		request.setAttribute("listStud", StudList);
		
		List<Classess> subList = userDAO.selectAllClasses(); 
		//System.out.println(subList);
		request.setAttribute("listSub", subList);
		
		request.getRequestDispatcher("Student-Form.jsp").include(request, response);
	

	}


	private void StudentForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub

		List<Student> StudList = userDAO.selectAllStudents(); 
		//System.out.println(TeachList);
		request.setAttribute("listStud", StudList);
		
		List<Classess> subList = userDAO.selectAllClasses(); 
		//System.out.println(subList);
		request.setAttribute("listSub", subList);
		
		RequestDispatcher rd = request.getRequestDispatcher("Student-Form.jsp");
		rd.forward(request,response);

	}


	private void TeacherForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		List<Teacher> TeachList = userDAO.selectAllTeachers(); 
		//System.out.println(TeachList);
		request.setAttribute("listTeach", TeachList);
		
		List<Subject> subList = userDAO.selectAllSubjects(); 
		//System.out.println(subList);
		request.setAttribute("listSub", subList);
		
		RequestDispatcher rd = request.getRequestDispatcher("Teacher-Form.jsp");
		rd.forward(request,response);
		
	}


	private void NewTeacher(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException, ServletException {
		// TODO Auto-generated method stub

		PrintWriter writer = response.getWriter();
		String name=request.getParameter("teachername");
		String sname=request.getParameter("subjectname");

		System.out.println(name + "    Subject Name");
		Teacher newTeacher = new Teacher(name,sname);
		Boolean subExist = userDAO.insertNewTeacher(newTeacher);

		if (subExist)
			writer.println("<h3 style='color:green;'>Subject Already Exist.. + </h3>");	
		else
			writer.println("<h3 style='color:green;'>Subject Added Successfully.. + </h3>");
		
		
		List<Teacher> TeachList = userDAO.selectAllTeachers(); 
		request.setAttribute("listTeach", TeachList);
		
		List<Subject> subList = userDAO.selectAllSubjects(); 
		request.setAttribute("listSub", subList);
		
		request.getRequestDispatcher("Teacher-Form.jsp").include(request, response);
	

	}


	private void DeleteTeacher(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		// TODO Auto-generated method stub

		int id = Integer.parseInt(request.getParameter("id"));
		if(userDAO.deleteTeacher(id))
			{
			List<Teacher> TeachList = userDAO.selectAllTeachers(); 
			request.setAttribute("listTeach", TeachList);
			
			List<Subject> subList = userDAO.selectAllSubjects(); 
			request.setAttribute("listSub", subList);
			
			request.getRequestDispatcher("Teacher-Form.jsp").include(request, response);
			}
		else
			System.out.println("There is some error in deleting Teacher.");

	}


	private void userList1(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//System.out.println(request.getContextPath());
		System.out.println("useerlist1 1\n");
		System.out.println("There is some");
		//response.sendRedirect("login.html");
		
		System.out.println(request.getContextPath());
		//response.sendRedirect("login.html");
		response.sendRedirect("user-login.jsp");
		//request.getRequestDispatcher("login.html").include(request, response);
				
				
	}


	private void DeleteSubject(HttpServletRequest request, HttpServletResponse response) throws SQLException, ServletException, IOException {
		
		int id = Integer.parseInt(request.getParameter("id"));
		if(userDAO.deleteSubject(id))
			{
			List<Subject> subList = userDAO.selectAllSubjects(); 
			request.setAttribute("listUser", subList);
			request.getRequestDispatcher("Subject-Form.jsp").include(request, response);
			}
		else
			System.out.println("There is some error in deleting Subject.");
		
	}


	private void NewSubject(HttpServletRequest request, HttpServletResponse response) throws IOException, SQLException, ServletException {
		PrintWriter writer = response.getWriter();
		String name=request.getParameter("subjectname");

		System.out.println(name + "    Subject Name");
		Subject newSubject = new Subject(name);
		Boolean subExist = userDAO.insertNewSubject(newSubject);
		//response.sendRedirect("list");
		//request.getRequestDispatcher("Class-Form.jsp").include(request, response);
		if (subExist)
			writer.println("<h3 style='color:green;'>Subject Already Exist.. + </h3>");	
		else
			writer.println("<h3 style='color:green;'>Subject Added Successfully.. + </h3>");
		
		
		List<Subject> subList = userDAO.selectAllSubjects(); 
		request.setAttribute("listUser", subList);
		request.getRequestDispatcher("Subject-Form.jsp").include(request, response);
	
		
	}


	private void SubjectForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("SubjectForm 1\n");
		List<Subject> subList = userDAO.selectAllSubjects(); 
		System.out.println(subList);
		request.setAttribute("listUser", subList);
		System.out.println("SubjectForm 2\n");
		RequestDispatcher rd = request.getRequestDispatcher("Subject-Form.jsp");
		System.out.println("SubjectForm 3\n");
		rd.forward(request,response);
		
		
	}


	private void DeleteClasses(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException {

		int id = Integer.parseInt(request.getParameter("id"));
		if(userDAO.deleteClass(id))
			{
				List<Classess> userList = userDAO.selectAllClasses(); 
				request.setAttribute("listUser", userList);
				request.getRequestDispatcher("Class-Form.jsp").include(request, response);
			}
		else
			System.out.println("There is some error in deleting user.");
		
	}


	private void NewClasses(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, SQLException {
		
		PrintWriter writer = response.getWriter();
		String name=request.getParameter("classname");

		System.out.println(name + "ClassName");
		Classess newclassess = new Classess(name);
		Boolean userExist = userDAO.insertNewClass(newclassess);
		//response.sendRedirect("list");
		//request.getRequestDispatcher("Class-Form.jsp").include(request, response);
		if (userExist)
			writer.println("<h3 style='color:green;'>Class User Already Exist.. + </h3>");	
		else
			writer.println("<h3 style='color:green;'>Class User Added Successfully.. + </h3>");
		
		
		List<Classess> userList = userDAO.selectAllClasses(); 
		request.setAttribute("listUser", userList);
		request.getRequestDispatcher("Class-Form.jsp").include(request, response);
		//rd.forward(request,response);
	}


	private void classForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("UserForm 1\n");
		List<Classess> userList =  userDAO.selectAllClasses(); 
		request.setAttribute("listUser", userList);
		RequestDispatcher rd = request.getRequestDispatcher("Class-Form.jsp");
		rd.forward(request,response);
		
	}


	private void adminNewUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException, ServletException  {
		
		PrintWriter writer = response.getWriter();
		String name=request.getParameter("name");
		String pwd = request.getParameter("password");
		System.out.println(pwd + "Password");
		UserAuth newUser = new UserAuth(name, pwd);
		Boolean userExist = userDAO.insertAdminUser(newUser);
		//response.sendRedirect("list");
		request.getRequestDispatcher("Admin-Form.jsp").include(request, response);
		if (userExist)
			writer.println("<h3 style='color:green;'>Admin User Already Exist.. + </h3>");	
		else
			writer.println("<h3 style='color:green;'>Admin User Added Successfully.. + </h3>");
	}


	private void adminForm(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("UserForm 1\n");
		RequestDispatcher rd = request.getRequestDispatcher("Admin-Form.jsp");
		rd.forward(request,response);
		
	}


	private void updateUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		//int id = Integer.parseInt(request.getParameter("id"));
		String name=request.getParameter("name");
		String email = request.getParameter("email");
		String country = request.getParameter("country");

		User modifiedUser = new User(ids,name, email, country);
		userDAO.updateUser(modifiedUser);
		response.sendRedirect("list");
		
		
	}


	private void userform(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		RequestDispatcher rd = request.getRequestDispatcher("User-Form.jsp");
		rd.forward(request,response);
	}


	private void editUser(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		ids = id;
		User existingUser = userDAO.selectUser(id);
		RequestDispatcher rd = request.getRequestDispatcher("Edit-Form.jsp");
		request.setAttribute("user", existingUser);
		rd.forward(request, response);
		
	}


	private void deleteUser(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		int id = Integer.parseInt(request.getParameter("id"));
		if(userDAO.deleteUser(id))
			response.sendRedirect("list");
		else
			System.out.println("There is some error in deleting user.");
		
	}


	private void userList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//List<User> userList = userDAO.selectAllUsers(); 
		//request.setAttribute("listUser", userList);
		//System.out.println(userList);
		//old code

		//request.getRequestDispatcher("login.html").include(request, response);
		System.out.println(request.getContextPath());
		RequestDispatcher rd = request.getRequestDispatcher("user-list.jsp");
		rd.forward(request,response);
	
		
	}


	private void userAdd(HttpServletRequest request, HttpServletResponse response) throws SQLException, IOException {
		String name=request.getParameter("name");
		String email = request.getParameter("email");
		String country = request.getParameter("country");
		User newUser = new User(name, email, country);
		userDAO.insertUser(newUser);
		response.sendRedirect("list");
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
